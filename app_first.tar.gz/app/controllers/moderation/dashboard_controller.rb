class Moderation::DashboardController < Moderation::BaseController
  def index
  end
end
