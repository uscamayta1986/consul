class Admin::DashboardController < Admin::BaseController
  def index
  end
end
