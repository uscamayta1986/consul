class Officing::DashboardController < Officing::BaseController
  def index
  end
end
