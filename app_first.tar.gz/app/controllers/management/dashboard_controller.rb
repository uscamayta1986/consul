class Management::DashboardController < Management::BaseController
  def index
  end
end
