module Dashboard
  def self.table_name_prefix
    "dashboard_"
  end
end
