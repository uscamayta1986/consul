module Legislation
  def self.table_name_prefix
    "legislation_"
  end
end
