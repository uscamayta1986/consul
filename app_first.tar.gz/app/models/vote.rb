class Vote < ActsAsVotable::Vote
end
