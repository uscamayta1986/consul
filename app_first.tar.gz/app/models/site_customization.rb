module SiteCustomization
  def self.table_name_prefix
    "site_customization_"
  end
end
