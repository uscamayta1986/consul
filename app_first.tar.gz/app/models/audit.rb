class Audit < Audited::Audit
end
