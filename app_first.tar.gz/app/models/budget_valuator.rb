class BudgetValuator < ApplicationRecord
  belongs_to :budget
  belongs_to :valuator
end
