class GeozonesPoll < ApplicationRecord
  belongs_to :geozone
  belongs_to :poll
end
