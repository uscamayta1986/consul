class Tagging < ActsAsTaggableOn::Tagging
end
