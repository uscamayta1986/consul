class Tag < ActsAsTaggableOn::Tag
end
