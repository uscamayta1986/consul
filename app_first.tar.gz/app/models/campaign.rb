class Campaign < ApplicationRecord
end
